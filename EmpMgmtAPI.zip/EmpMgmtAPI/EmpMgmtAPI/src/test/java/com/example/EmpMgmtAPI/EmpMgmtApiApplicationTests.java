package com.example.EmpMgmtAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpMgmtApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
